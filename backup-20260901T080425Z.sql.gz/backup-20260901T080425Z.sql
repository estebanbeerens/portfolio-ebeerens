--
-- PostgreSQL database dump
--

\restrict 70YgxeobeC51HbNKB0W5X1WVtFNijL2PxcnxeJt6R2psgUSPpOXMKWKcRcbohVW

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ActivityAction; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public."ActivityAction" AS ENUM (
    'CREATED',
    'UPDATED',
    'DELETED'
);


ALTER TYPE public."ActivityAction" OWNER TO admin;

--
-- Name: ActivityEntity; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public."ActivityEntity" AS ENUM (
    'PROFILE',
    'PROJECT',
    'ROLE',
    'ORGANIZATION',
    'RESUME'
);


ALTER TYPE public."ActivityEntity" OWNER TO admin;

--
-- Name: EmploymentType; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public."EmploymentType" AS ENUM (
    'FULL_TIME',
    'PART_TIME',
    'SELF_EMPLOYED',
    'FREELANCE',
    'INTERNSHIP',
    'TRAINEE',
    'APPRENTICESHIP',
    'SEASONAL'
);


ALTER TYPE public."EmploymentType" OWNER TO admin;

--
-- Name: FeatureFlagKey; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public."FeatureFlagKey" AS ENUM (
    'CONTACT',
    'PROJECTS',
    'ROLES',
    'RESUME'
);


ALTER TYPE public."FeatureFlagKey" OWNER TO admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ActivityLog; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."ActivityLog" (
    id text NOT NULL,
    "entityType" public."ActivityEntity" NOT NULL,
    "entityId" text,
    action public."ActivityAction" NOT NULL,
    summary text NOT NULL,
    actor text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ActivityLog" OWNER TO admin;

--
-- Name: ContactMessage; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."ContactMessage" (
    id text NOT NULL,
    "fullName" text NOT NULL,
    email text NOT NULL,
    subject text NOT NULL,
    message text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    organization text,
    "isRead" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."ContactMessage" OWNER TO admin;

--
-- Name: FeatureFlag; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."FeatureFlag" (
    key public."FeatureFlagKey" NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."FeatureFlag" OWNER TO admin;

--
-- Name: Organization; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Organization" (
    id text NOT NULL,
    name text NOT NULL,
    "logoUrl" text,
    website text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "logoObjectKey" text
);


ALTER TABLE public."Organization" OWNER TO admin;

--
-- Name: Profile; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Profile" (
    id text NOT NULL,
    name text NOT NULL,
    headline text,
    "bioEn" text,
    "avatarUrl" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "githubUrl" text,
    "instagramUrl" text,
    "linkedinUrl" text,
    location text,
    "xUrl" text,
    "youtubeUrl" text,
    "bioNl" text
);


ALTER TABLE public."Profile" OWNER TO admin;

--
-- Name: Project; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Project" (
    id text NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    "descriptionEn" text NOT NULL,
    "imageUrl" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    client text,
    "jobRole" text,
    "liveUrl" text,
    "endDate" timestamp(3) without time zone,
    "startDate" timestamp(3) without time zone NOT NULL,
    "shortDescriptionEn" character varying(255) NOT NULL,
    "imageObjectKey" text,
    "shortDescriptionNl" character varying(255),
    "descriptionNl" text
);


ALTER TABLE public."Project" OWNER TO admin;

--
-- Name: Resume; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Resume" (
    id text NOT NULL,
    "fileName" text NOT NULL,
    "objectKey" text NOT NULL,
    "mimeType" text NOT NULL,
    "fileSize" integer NOT NULL,
    "uploadedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Resume" OWNER TO admin;

--
-- Name: ResumeDownload; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."ResumeDownload" (
    id text NOT NULL,
    "resumeId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ResumeDownload" OWNER TO admin;

--
-- Name: Role; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Role" (
    id text NOT NULL,
    "jobTitle" text NOT NULL,
    "organizationId" text NOT NULL,
    location text,
    "employmentType" public."EmploymentType",
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "descriptionEn" text,
    "descriptionNl" text
);


ALTER TABLE public."Role" OWNER TO admin;

--
-- Name: Session; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "tokenHash" text NOT NULL,
    "githubUserId" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "displayName" text,
    "avatarUrl" text
);


ALTER TABLE public."Session" OWNER TO admin;

--
-- Name: Skill; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Skill" (
    id text NOT NULL,
    name text NOT NULL
);


ALTER TABLE public."Skill" OWNER TO admin;

--
-- Name: _ProjectToSkill; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."_ProjectToSkill" (
    "A" text NOT NULL,
    "B" text NOT NULL
);


ALTER TABLE public."_ProjectToSkill" OWNER TO admin;

--
-- Name: _RoleToSkill; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."_RoleToSkill" (
    "A" text NOT NULL,
    "B" text NOT NULL
);


ALTER TABLE public."_RoleToSkill" OWNER TO admin;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO admin;

--
-- Data for Name: ActivityLog; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."ActivityLog" (id, "entityType", "entityId", action, summary, actor, "createdAt") FROM stdin;
cmsyqzhld0006i3pqzdu3vqw2	PROJECT	cmsyqzhjz0000i3pqhiie2pc3	CREATED	Added project "MyHealth Belgium"	Esteban Beerens	2026-08-18 14:18:11.281
cmsywa0vb00002wpquj4yvlom	PROJECT	cmsyqzhjz0000i3pqhiie2pc3	UPDATED	Updated project "MyHealth Belgium"	Esteban Beerens	2026-08-18 16:46:20.903
cmsywa9kx00012wpq2mygvswj	PROJECT	cmsyqzhjz0000i3pqhiie2pc3	UPDATED	Updated project "MyHealth Belgium"	Esteban Beerens	2026-08-18 16:46:32.193
cmsywcysu00032wpqwt3mm2h5	PROJECT	cmsywcysh00022wpqvvjfatpz	CREATED	Added project "Test project"	Esteban Beerens	2026-08-18 16:48:38.19
cmsywd6xo00042wpqj4ljzrnv	PROJECT	\N	DELETED	Deleted project "Test project"	Esteban Beerens	2026-08-18 16:48:48.732
cmsywhoor00052wpqgcrm751m	PROJECT	cmsyqzhjz0000i3pqhiie2pc3	UPDATED	Updated project "MyHealth Belgium"	Esteban Beerens	2026-08-18 16:52:18.363
cmszvpalw0000rtpqxknk57vy	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-19 09:17:59.924
cmszvsbl50001rtpqhh2eq8kx	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-19 09:20:21.161
cmszvshzj0002rtpqwkftb7ql	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-19 09:20:29.455
cmt00v4wh0001wbpqyjeibcaq	ORGANIZATION	cmt00v4wa0000wbpq4psbs8q5	CREATED	Added organization "Sopra Steria"	Esteban Beerens	2026-08-19 11:42:30.545
cmt00v4xi0003wbpqmthhuao8	ROLE	cmt00v4xb0002wbpqzcd1qi0q	CREATED	Added Frontend developer position at Sopra Steria	Esteban Beerens	2026-08-19 11:42:30.582
cmt00vxfy0004wbpqjguqwsac	ROLE	cmt00v4xb0002wbpqzcd1qi0q	UPDATED	Updated Frontend developer position at Sopra Steria	Esteban Beerens	2026-08-19 11:43:07.534
cmt00wcpr0006wbpqtwksl0wd	ROLE	cmt00wcpg0005wbpq2jc739sk	CREATED	Added Lead frontend developer position at Sopra Steria	Esteban Beerens	2026-08-19 11:43:27.327
cmt00xmcv0007wbpq0zwtj26h	ORGANIZATION	cmt00v4wa0000wbpq4psbs8q5	UPDATED	Updated organization "Sopra Steria"	Esteban Beerens	2026-08-19 11:44:26.479
cmt00z7hn0008wbpquxf8zty1	ROLE	cmt00wcpg0005wbpq2jc739sk	UPDATED	Updated Lead frontend developer position at Sopra Steria	Esteban Beerens	2026-08-19 11:45:40.523
cmt00zq4d000awbpqwl6aukjy	ROLE	cmt00zq410009wbpqrrknztw8	CREATED	Added Test position at Sopra Steria	Esteban Beerens	2026-08-19 11:46:04.669
cmt00ztar000bwbpqjr5fo9wb	ROLE	\N	DELETED	Deleted Test position at Sopra Steria	Esteban Beerens	2026-08-19 11:46:08.787
cmt010ysf000cwbpqxnky9f0v	PROJECT	cmsyqzhjz0000i3pqhiie2pc3	UPDATED	Updated project "MyHealth Belgium"	Esteban Beerens	2026-08-19 11:47:02.559
cmt017mxq000dwbpqss78rk3g	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-19 11:52:13.79
cmt02jzkl0001j0pqbtf9l3dt	PROJECT	cmsyqzhjz0000i3pqhiie2pc3	UPDATED	Updated project "MyHealth Belgium"	Esteban Beerens	2026-08-19 12:29:49.653
cmt046fov0001o7pq9zlhxn39	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-19 13:15:16.591
cmt04aq7f0004o7pqlmxqtbbx	ROLE	cmt04aq6p0002o7pqps2ciclz	CREATED	Added Digital Accessibility Leader for Belux position at Sopra Steria	Esteban Beerens	2026-08-19 13:18:36.843
cmt04bysv0006o7pq16rk7nmf	ORGANIZATION	cmt04byso0005o7pqri3jv4cw	CREATED	Added organization "Easi"	Esteban Beerens	2026-08-19 13:19:34.639
cmt04bytz0008o7pqjqjhytc2	ROLE	cmt04byto0007o7pq4vo54svo	CREATED	Added Consultant position at Easi	Esteban Beerens	2026-08-19 13:19:34.68
cmt04cz9e000ao7pqio8ws40n	ORGANIZATION	cmt04cz980009o7pqbzt3kaz1	CREATED	Added organization "Routty"	Esteban Beerens	2026-08-19 13:20:21.89
cmt04czah000co7pq2mdvcksr	ROLE	cmt04cza7000bo7pq5zhgxnc2	CREATED	Added Frontend Product Developer position at Routty	Esteban Beerens	2026-08-19 13:20:21.929
cmt04e8yb000eo7pq74wslngq	ORGANIZATION	cmt04e8y6000do7pq023jk1v2	CREATED	Added organization "University of Vienna"	Esteban Beerens	2026-08-19 13:21:21.107
cmt04e8zh000go7pqqj3anm0t	ROLE	cmt04e8z4000fo7pqhx8nj4iv	CREATED	Added Software Developer position at University of Vienna	Esteban Beerens	2026-08-19 13:21:21.149
cmt04glxq000io7pq7s3oc3z8	ORGANIZATION	cmt04glxk000ho7pqx5zog8hl	CREATED	Added organization "3-it"	Esteban Beerens	2026-08-19 13:23:11.246
cmt04glzl000lo7pqrcgv0s2c	ROLE	cmt04glyk000jo7pq9xk6kfef	CREATED	Added Frontend Developer position at 3-it	Esteban Beerens	2026-08-19 13:23:11.313
cmt04jdnc000mo7pqb47il5qm	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-19 13:25:20.472
cmt04kzr0000no7pqtc2zxvip	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-19 13:26:35.773
cmt04l9h5000oo7pq2f6tv3q6	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-19 13:26:48.377
cmt04nz5g000po7pq6qv5pq94	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-19 13:28:54.964
cmt05h277000qo7pq96y33zyu	ROLE	cmt04glyk000jo7pq9xk6kfef	UPDATED	Updated Frontend Developer position at 3-it	Esteban Beerens	2026-08-19 13:51:31.939
cmt05k716000ro7pqtao2dk3d	ROLE	cmt04aq6p0002o7pqps2ciclz	UPDATED	Updated Digital Accessibility Leader for Belux position at Sopra Steria	Esteban Beerens	2026-08-19 13:53:58.17
cmt05k9gq000so7pqzep8btlo	ROLE	cmt00wcpg0005wbpq2jc739sk	UPDATED	Updated Lead frontend developer position at Sopra Steria	Esteban Beerens	2026-08-19 13:54:01.322
cmt05kbgk000to7pqdcd8bgop	ROLE	cmt00v4xb0002wbpqzcd1qi0q	UPDATED	Updated Frontend developer position at Sopra Steria	Esteban Beerens	2026-08-19 13:54:03.909
cmt05phij000uo7pq902lkwsp	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-19 13:58:05.035
cmt05pyq1000vo7pqwa8l5wal	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-19 13:58:27.337
cmt06p52g000wo7pqbdvg78dz	PROJECT	cmsyqzhjz0000i3pqhiie2pc3	UPDATED	Updated project "MyHealth Belgium"	Esteban Beerens	2026-08-19 14:25:48.52
cmt06ugk6000xo7pq0pbbcdma	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-19 14:29:56.694
cmt19odb900015ipqrc58umcp	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-20 08:36:57.573
cmt19ojri00025ipquzblcewx	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-20 08:37:05.934
cmt1aemxp0000k1pqlhxrot59	PROJECT	cmsyqzhjz0000i3pqhiie2pc3	UPDATED	Updated project "MyHealth Belgium"	Esteban Beerens	2026-08-20 08:57:23.101
cmt1ako7n0002k1pqve53zcs6	PROJECT	cmt1ako7a0001k1pqi0iun5ij	CREATED	Added project "Thomas & Piron"	Esteban Beerens	2026-08-20 09:02:04.691
cmt1al55u0003k1pquxuovgj3	PROJECT	cmsyqzhjz0000i3pqhiie2pc3	UPDATED	Updated project "MyHealth Belgium"	Esteban Beerens	2026-08-20 09:02:26.658
cmt1aldgg0004k1pq332nfe9x	PROJECT	cmsyqzhjz0000i3pqhiie2pc3	UPDATED	Updated project "MyHealth Belgium"	Esteban Beerens	2026-08-20 09:02:37.408
cmt1alpma0005k1pqz6zd3y3j	PROJECT	cmsyqzhjz0000i3pqhiie2pc3	UPDATED	Updated project "MyHealth Belgium"	Esteban Beerens	2026-08-20 09:02:53.17
cmt1b20rz0000pdpq0aywj8ru	PROJECT	cmsyqzhjz0000i3pqhiie2pc3	UPDATED	Updated project "MyHealth Belgium"	Esteban Beerens	2026-08-20 09:15:34.127
cmt1b357n0001pdpq2uxzxls4	ROLE	cmt04aq6p0002o7pqps2ciclz	UPDATED	Updated Digital Accessibility Leader for Belux position at Sopra Steria	Esteban Beerens	2026-08-20 09:16:26.531
cmt1bcy8p0000ylpqu4h2h7o9	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-20 09:24:04.057
cmt1bd4qv0001ylpqwim45q4o	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-20 09:24:12.487
cmt1bdc2a0002ylpqcpgfxj62	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-20 09:24:21.97
cmt1bfez90004ylpqykopfikj	PROJECT	cmt1ako7a0001k1pqi0iun5ij	UPDATED	Updated project "Thomas & Piron"	Esteban Beerens	2026-08-20 09:25:59.061
cmt1ehwy50005ylpqsrg7xoqq	PROJECT	cmsyqzhjz0000i3pqhiie2pc3	UPDATED	Updated project "MyHealth Belgium"	Esteban Beerens	2026-08-20 10:51:54.509
cmt1eij910006ylpq1j2zvkvu	PROJECT	cmsyqzhjz0000i3pqhiie2pc3	UPDATED	Updated project "MyHealth Belgium"	Esteban Beerens	2026-08-20 10:52:23.413
cmt1eimiw0007ylpqqs5jsttz	PROJECT	cmsyqzhjz0000i3pqhiie2pc3	UPDATED	Updated project "MyHealth Belgium"	Esteban Beerens	2026-08-20 10:52:27.656
cmt1eip1y0008ylpq4pcsh4ry	PROJECT	cmsyqzhjz0000i3pqhiie2pc3	UPDATED	Updated project "MyHealth Belgium"	Esteban Beerens	2026-08-20 10:52:30.934
cmt1ej49p0009ylpqm0tjrsrj	ROLE	cmt04aq6p0002o7pqps2ciclz	UPDATED	Updated Digital Accessibility Leader for Belux position at Sopra Steria	Esteban Beerens	2026-08-20 10:52:50.653
cmt1ejmhu000aylpq8kt9skv6	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-20 10:53:14.274
cmt1ejw8r000bylpq6xipedhv	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-20 10:53:26.907
cmt1mfqgs00003gpqxvoc64ps	PROJECT	cmsyqzhjz0000i3pqhiie2pc3	UPDATED	Updated project "MyHealth Belgium"	Esteban Beerens	2026-08-20 14:34:09.724
cmt1mgkn200023gpq4urw30qn	RESUME	cmt1mgkmp00013gpqp9w0gk1h	CREATED	Uploaded resume "sample.pdf"	Esteban Beerens	2026-08-20 14:34:48.83
cmt1mmfx500033gpqqo58f5hu	PROJECT	cmsyqzhjz0000i3pqhiie2pc3	UPDATED	Updated project "MyHealth Belgium"	Esteban Beerens	2026-08-20 14:39:22.649
cmt1mmwi000043gpqi1r1xknk	PROJECT	cmsyqzhjz0000i3pqhiie2pc3	UPDATED	Updated project "MyHealth Belgium"	Esteban Beerens	2026-08-20 14:39:44.136
cmt1mn3x100053gpqqv4aswrn	PROJECT	cmsyqzhjz0000i3pqhiie2pc3	UPDATED	Updated project "MyHealth Belgium"	Esteban Beerens	2026-08-20 14:39:53.749
cmt2ndpww0001pxpqci7gatwo	ORGANIZATION	cmt00v4wa0000wbpq4psbs8q5	UPDATED	Updated organization "Sopra Steria"	Esteban Beerens	2026-08-21 07:48:21.488
cmt2ner260002pxpqb473342r	ORGANIZATION	cmt04byso0005o7pqri3jv4cw	UPDATED	Updated organization "Easi"	Esteban Beerens	2026-08-21 07:49:09.63
cmt36akp300002epqqvdiu5ak	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-21 16:37:47.463
cmt36baxy00012epqapla1k8o	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-21 16:38:21.478
cmt36c6lw00022epqpomxchl2	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-21 16:39:02.516
cmtae6t1k000001p8e5o2ti5m	ORGANIZATION	cmt00v4wa0000wbpq4psbs8q5	UPDATED	Updated organization "Sopra Steria"	Esteban Beerens	2026-08-26 17:53:11.816
cmtae6x6m000101p8w7xzy08s	ORGANIZATION	cmt04byso0005o7pqri3jv4cw	UPDATED	Updated organization "Easi"	Esteban Beerens	2026-08-26 17:53:17.182
cmtae9oi2000201p8rz8ocbg1	ORGANIZATION	cmt00v4wa0000wbpq4psbs8q5	UPDATED	Updated organization "Sopra Steria"	Esteban Beerens	2026-08-26 17:55:25.898
cmtae9sps000301p8nyn4fgfd	ORGANIZATION	cmt04byso0005o7pqri3jv4cw	UPDATED	Updated organization "Easi"	Esteban Beerens	2026-08-26 17:55:31.36
cmtgxhc7i000101mo7rnk6bd4	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-31 07:39:52.974
cmtgxhhue000201moztv9391t	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-31 07:40:00.278
cmtgxk57c000301moi814dlum	ORGANIZATION	cmt04cz980009o7pqbzt3kaz1	UPDATED	Updated organization "Routty"	Esteban Beerens	2026-08-31 07:42:03.864
cmtgxkjg2000401mo13qtmhu6	ORGANIZATION	cmt04e8y6000do7pq023jk1v2	UPDATED	Updated organization "University of Vienna"	Esteban Beerens	2026-08-31 07:42:22.322
cmtgxktcx000501moawnezj2y	ORGANIZATION	cmt04glxk000ho7pqx5zog8hl	UPDATED	Updated organization "3-it"	Esteban Beerens	2026-08-31 07:42:35.169
cmtgxn9nn000001roelsl8lfp	PROJECT	cmsyqzhjz0000i3pqhiie2pc3	UPDATED	Updated project "MyHealth Belgium"	Esteban Beerens	2026-08-31 07:44:29.603
cmth1vh7t000001qsjm1kppqi	PROJECT	cmt1ako7a0001k1pqi0iun5ij	UPDATED	Updated project "Thomas & Piron"	Esteban Beerens	2026-08-31 09:42:51.114
cmth28pl6000401qsyq25e924	PROJECT	cmth28pkq000101qsl4k9cio8	CREATED	Added project "Runners App"	Esteban Beerens	2026-08-31 09:53:08.49
cmth2a98z000501qsw8y6lvyo	PROJECT	cmth28pkq000101qsl4k9cio8	UPDATED	Updated project "Runners App"	Esteban Beerens	2026-08-31 09:54:20.627
cmth2igy0000901qs4ql6jn6f	PROJECT	cmth2igxe000601qsbgblqpjj	CREATED	Added project "G&G CRM App"	Esteban Beerens	2026-08-31 10:00:43.848
cmth2jb50000a01qs06c6fi87	PROJECT	cmth28pkq000101qsl4k9cio8	UPDATED	Updated project "Runners App"	Esteban Beerens	2026-08-31 10:01:22.98
cmth2jzo3000c01qsodkcuaid	PROJECT	cmth28pkq000101qsl4k9cio8	UPDATED	Updated project "Runners App"	Esteban Beerens	2026-08-31 10:01:54.772
cmth3ytcv000h01qsy4rv00cj	PROJECT	cmth3ytci000d01qsvgolc0cu	CREATED	Added project "DLBT"	Esteban Beerens	2026-08-31 10:41:26.047
cmth3zyyx000i01qsfizi80wi	PROJECT	cmth3ytci000d01qsvgolc0cu	UPDATED	Updated project "DLBT"	Esteban Beerens	2026-08-31 10:42:19.977
cmth45lk9000n01qsuxku5z3w	PROJECT	cmth45ljq000j01qsumb536gr	CREATED	Added project "Routty"	Esteban Beerens	2026-08-31 10:46:42.537
cmth47w4i000o01qs2tmczov3	PROJECT	cmth3ytci000d01qsvgolc0cu	UPDATED	Updated project "Digital Library and Bibliography for Literature in Translation and Adaptation"	Esteban Beerens	2026-08-31 10:48:29.538
cmth48t9m000p01qstqizax7s	PROJECT	cmth3ytci000d01qsvgolc0cu	UPDATED	Updated project "DLBT"	Esteban Beerens	2026-08-31 10:49:12.49
cmth4d4fe000x01qsxxhg1htp	PROJECT	cmth4d4ek000q01qst2rbggmx	CREATED	Added project "Sopraco Sharepoint"	Esteban Beerens	2026-08-31 10:52:33.578
cmth4df2f000y01qs3c05e8tv	PROJECT	cmth45ljq000j01qsumb536gr	UPDATED	Updated project "Routty"	Esteban Beerens	2026-08-31 10:52:47.367
cmth4dknx000z01qs7boeuff7	PROJECT	cmth45ljq000j01qsumb536gr	UPDATED	Updated project "Routty"	Esteban Beerens	2026-08-31 10:52:54.621
cmth4hrbk001501qsnuxlj6n8	PROJECT	cmth4hrb4001001qser2cv44g	CREATED	Added project "GT data migration"	Esteban Beerens	2026-08-31 10:56:09.872
cmth4n078001801qsp2jj1jo1	PROJECT	cmth4n06s001601qso6rkhpdk	CREATED	Added project "Democo templating tool"	Esteban Beerens	2026-08-31 11:00:14.66
cmth4pkl6001901qsfnolcsvu	PROJECT	cmth4hrb4001001qser2cv44g	UPDATED	Updated project "GT data migration"	Esteban Beerens	2026-08-31 11:02:14.394
cmth6wgei001b01qskyaci6mu	PROJECT	cmth6wge7001a01qswpyydgqx	CREATED	Added project "DHL M365 migration"	Esteban Beerens	2026-08-31 12:03:34.794
cmth6x1c9001c01qsyupvod22	PROJECT	cmth4d4ek000q01qst2rbggmx	UPDATED	Updated project "Sopraco Sharepoint"	Esteban Beerens	2026-08-31 12:04:01.929
cmth6xa8x001d01qsq3e25mg8	PROJECT	cmth6wge7001a01qswpyydgqx	UPDATED	Updated project "DHL M365 migration"	Esteban Beerens	2026-08-31 12:04:13.473
cmth6xfb9001e01qs7it4jhiq	PROJECT	cmth6wge7001a01qswpyydgqx	UPDATED	Updated project "DHL M365 migration"	Esteban Beerens	2026-08-31 12:04:20.037
cmth71sl0001i01qsq701wlm0	PROJECT	cmth71skb001f01qsrisbzd0y	CREATED	Added project "TCM Belgium Web"	Esteban Beerens	2026-08-31 12:07:43.86
cmth75t4u001k01qsbp2fk9uy	PROJECT	cmth75t4l001j01qsfu7tofh9	CREATED	Added project "Pioneer Europe Lotus Notes support"	Esteban Beerens	2026-08-31 12:10:51.198
cmth7bo0m001o01qsbduo97xm	PROJECT	cmth7bnzz001l01qsgsd1xf6h	CREATED	Added project "SQAS 2.0"	Esteban Beerens	2026-08-31 12:15:24.502
cmth7w6pf001s01qsn2sdr7ay	PROJECT	cmth7w6ov001p01qs647j4sc4	CREATED	Added project "Vitals Design System"	Esteban Beerens	2026-08-31 12:31:21.843
cmth80zxc001t01qsqwfjfc1l	PROJECT	\N	DELETED	Deleted project "MyHealth Belgium"	Esteban Beerens	2026-08-31 12:35:06.336
cmth8116o001u01qsms0flq2e	PROJECT	\N	DELETED	Deleted project "Thomas & Piron"	Esteban Beerens	2026-08-31 12:35:07.968
cmth8b5c5001w01qsnnosloni	PROJECT	cmth8b5at001v01qsy6r3wwad	CREATED	Added project "Thomas & Piron 3.0: New websites"	Esteban Beerens	2026-08-31 12:42:59.909
cmth8ghla001x01qsiyp7rru8	PROJECT	cmth8b5at001v01qsy6r3wwad	UPDATED	Updated project "Thomas & Piron 3.0: New websites"	Esteban Beerens	2026-08-31 12:47:09.07
cmth8y9y7001z01qslok8he4f	PROJECT	cmth8y9xp001y01qslx1aiafy	CREATED	Added project "MyHealth Belgium"	Esteban Beerens	2026-08-31 13:00:58.975
cmth924cs002001qsjyq5g5ef	PROJECT	cmth8y9xp001y01qslx1aiafy	UPDATED	Updated project "MyHealth Belgium"	Esteban Beerens	2026-08-31 13:03:58.348
cmth9tlih002501qs2awk6k3h	PROJECT	cmth9tli0002201qsem25hbba	CREATED	Added project "CM Gezonde Buurt (Healthy Neighbourhood)"	Esteban Beerens	2026-08-31 13:25:20.297
cmth9wxzj002701qs1v6fwj5k	PROJECT	cmth9wxz8002601qsh1jkny76	CREATED	Added project "Agoria Assistant"	Esteban Beerens	2026-08-31 13:27:56.431
cmtha0wv7002901qsk7ky02xf	PROJECT	cmtha0wuo002801qsttpg6vk0	CREATED	Added project "Thomas & Piron: websites maintenance"	Esteban Beerens	2026-08-31 13:31:01.603
cmtha44de002a01qsphw813am	PROFILE	cmsssot9m0000p6pq94h51j65	UPDATED	Updated profile details	Esteban Beerens	2026-08-31 13:33:31.298
\.


--
-- Data for Name: ContactMessage; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."ContactMessage" (id, "fullName", email, subject, message, "createdAt", organization, "isRead") FROM stdin;
cmth97p5w002101qs5xd77trn	James T. Kirk	james.kirk@gmail.com	Beyond the stars	Star trek is cool	2026-08-31 13:08:18.596	\N	t
\.


--
-- Data for Name: FeatureFlag; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."FeatureFlag" (key, enabled, "updatedAt") FROM stdin;
ROLES	t	2026-08-21 08:55:39.851
PROJECTS	t	2026-08-21 08:55:30.755
RESUME	f	2026-08-27 13:33:34.196
CONTACT	t	2026-08-31 13:10:19.804
\.


--
-- Data for Name: Organization; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Organization" (id, name, "logoUrl", website, "createdAt", "updatedAt", "logoObjectKey") FROM stdin;
cmt00v4wa0000wbpq4psbs8q5	Sopra Steria	https://cdn.ebeerens.com/organizations/a0f4cec4-7a03-4eed-a4ad-4ea3ca7a6c9f.jpeg	https://www.soprasteria.be/	2026-08-19 11:42:30.538	2026-08-26 17:55:25.895	organizations/a0f4cec4-7a03-4eed-a4ad-4ea3ca7a6c9f.jpeg
cmt04byso0005o7pqri3jv4cw	Easi	https://cdn.ebeerens.com/organizations/004d57e7-c52f-4150-aa5c-d8c36e50263d.jpeg	https://easi.net/	2026-08-19 13:19:34.632	2026-08-26 17:55:31.358	organizations/004d57e7-c52f-4150-aa5c-d8c36e50263d.jpeg
cmt04cz980009o7pqbzt3kaz1	Routty	https://cdn.ebeerens.com/organizations/d7600567-1ac2-4020-a081-e8ba45b5ae07.jpeg	https://www.dynatos.com/software/routty/	2026-08-19 13:20:21.884	2026-08-31 07:42:03.858	organizations/d7600567-1ac2-4020-a081-e8ba45b5ae07.jpeg
cmt04e8y6000do7pq023jk1v2	University of Vienna	https://cdn.ebeerens.com/organizations/afc26d31-930f-4f22-b57c-ad622eda181c.jpeg	https://www.univie.ac.at/	2026-08-19 13:21:21.102	2026-08-31 07:42:22.319	organizations/afc26d31-930f-4f22-b57c-ad622eda181c.jpeg
cmt04glxk000ho7pqx5zog8hl	3-it	https://cdn.ebeerens.com/organizations/aeba78b6-834d-4128-a73b-9ac2a81714b2.jpeg	https://3-it.be/	2026-08-19 13:23:11.24	2026-08-31 07:42:35.167	organizations/aeba78b6-834d-4128-a73b-9ac2a81714b2.jpeg
\.


--
-- Data for Name: Profile; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Profile" (id, name, headline, "bioEn", "avatarUrl", "updatedAt", "githubUrl", "instagramUrl", "linkedinUrl", location, "xUrl", "youtubeUrl", "bioNl") FROM stdin;
cmsssot9m0000p6pq94h51j65	Esteban Beerens	Digital Experience Architect	With a natural eye for perfection and a creative mind, I love creating applications, beautiful websites and scalable architectures.\n\nI have many passions and hobbies, such as culture, history, swimming and watching football (soccer). Although my biggest passion has always been designing and creating websites and applications.\n\nWhen I'm not at the office, you'll often find me tinkering with my own tech or somewhere in any body of water; be it near own shores or far away in distant waters.	https://avatars.githubusercontent.com/u/37366585?v=4	2026-08-31 13:33:31.295	https://github.com/estebanbeerens	\N	https://www.linkedin.com/in/ebeerens/	Leuven, Belgium	\N	\N	Met een natuurlijk oog voor perfectie en een creatieve geest houd ik ervan om applicaties, prachtige websites en schaalbare architecturen te ontwikkelen.\n\nIk heb veel passies en hobby’s, zoals cultuur, geschiedenis, zwemmen en voetbal kijken. Mijn grootste passie is echter altijd het ontwerpen en ontwikkelen van websites en applicaties geweest.\n\nAls ik niet op kantoor ben, ben ik vaak bezig met mijn eigen technische projecten of vind je me ergens in het water; of dat nu dicht bij de kust is of ver weg in verre wateren.\n\nVertaald met DeepL.com (gratis versie)
\.


--
-- Data for Name: Project; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Project" (id, title, slug, "descriptionEn", "imageUrl", "createdAt", "updatedAt", client, "jobRole", "liveUrl", "endDate", "startDate", "shortDescriptionEn", "imageObjectKey", "shortDescriptionNl", "descriptionNl") FROM stdin;
cmth2igxe000601qsbgblqpjj	G&G CRM App	gg-crm	Goelen & Gaukema is a small HR company that needed a CRM system for their internal and external procedures. In addition, the application needed to work with their already existing data in Azure and employees needed to be able to log into the system with their Microsoft account.\n3-it still had similar projects in the pipe, so the code had to be written as reusable as possible.\n\nMy tasks included:\n\n- Front-end development lead in Angular\n- State management with NgRx\n- Creating reusable components\n- UI and CSS validation in pull requests from other developers\n- Structuring Angular application for reusability\n- Azure AD SSO in Angular\nSmall changes in underlying .NET OpenAPI\n\nThe result was a high-quality application that allowed Goelen & Gaukema to perform their day-to-day tasks. They were very satisfied and purchased several more extensions.\nThe application was also easily reusable, making the development of other similar apps by 3-it up to 5 times faster.	\N	2026-08-31 10:00:43.826	2026-08-31 10:00:43.826	Goelen & Gaukema HR Partners	Lead front-end developer	\N	2021-01-01 00:00:00	2020-05-01 00:00:00	Goelen & Gaukema is a small HR company that needed a CRM system for their internal and external procedures. We created the CRM package in a way so it could be re-used for other customers.	\N	Goelen & Gaukema is een klein HR bedrijf dat nood had aan een CRM systeem voor hun interne en externe procedures. We bouwden het CRM systeem op een manier dat we het konden hergebruiken bij andere klanten.	Goelen & Gaukema is een klein HR bedrijf dat nood had aan een CRM systeem voor hun interne en externe procedures. Hiernaast moest de applicatie werken met hun reeds bestaande data in Azure en de medewerkers moesten kunnen inloggen in het systeem met hun Microsoft account.\n3-it had nog gelijkaardige projecten in aanloop, dus de code moest zo herbruikbaar mogelijk geschreven worden.\n\nMijn taken waren:\n\n- Front-end development lead in Angular\n- State management met NgRx\n- Herbruikbare componenten maken\n- UI en CSS validatie in pull requests van andere developers\n- Structureren van Angular applicatie voor herbruikbaarheid\n- Azure AD SSO in Angular\n- Kleine aanpassingen in achterliggende .NET OpenAPI\n\n\nHet resultaat was een hoogwaardige applicatie waarmee Goelen & Gaukema aan de slag kon om de dagdagelijkse taken uit te voeren. Ze waren erg tevreden en hebben nog enkele uitbreidingen aangekocht.\nDaarnaast was de applicatie ook makkelijk herbruikbaar, wat de ontwikkeling van andere gelijkaardige apps door 3-it tot 5 keer sneller heeft gemaakt.\nThe result was a high-quality application that allowed Goelen & Gaukema to perform their day-to-day tasks. They were very satisfied and purchased several more extensions.\nThe application was also easily reusable, making the development of other similar apps by 3-it up to 5 times faster.
cmth28pkq000101qsl4k9cio8	Runners App	runners	Runners Mol is a company that specialises in ergonomic running shoes. It required a mobile app to allow the employees to compare videos of its customers using different shoes to compare the performances.\n\nMy tasks included:\n\n- Investigate best framework for this application (Xamarin or Flutter)\n- Create design mockups of the application in Figma\n- Create architecture for the application\n- Development of the application in Flutter\n- Communication from the Flutter app to an existing .NET back-end\n\nThe Flutter app enabled Runners Mol to create a high-quality, native mobile app that met the requirements for comparing videos of customers using different shoes. The app provided a seamless experience for employees, allowing them to analyse customer performance effectively.	\N	2026-08-31 09:53:08.474	2026-08-31 10:01:54.733	Runners Mol	Mobile developer	\N	2020-05-01 00:00:00	2019-11-01 00:00:00	Runners Mol is a company that specialises in ergonomic running shoes. It required a mobile app to allow the employees to compare videos of its customers using different shoes to compare the performances.	\N	Runners Mol is een bedrijf dat gespecialiseerd is in ergonomische hardloopschoenen. Het had een mobiele app nodig waarmee de medewerkers video's van hun klanten met verschillende schoenen konden vergelijken om de prestaties te vergelijken.	Runners Mol is een bedrijf dat gespecialiseerd is in ergonomische hardloopschoenen. Het had een mobiele app nodig waarmee de medewerkers video's van hun klanten met verschillende schoenen konden vergelijken om de prestaties te vergelijken.\n\nMijn taken waren:\n\n- Onderzoeken beste framework voor deze applicatie (Xamarin of Flutter)\n- Design mockups maken van de applicatie in Figma\n- Architectuur voor de applicatie maken\n- Development van de applicatie in Flutter\n- Communicatie vanuit de Flutter app naar een reeds bestaande .NET back-end\n\nDe Flutter app stelde Runners Mol in staat om een hoogwaardige, native mobiele app te creëren die voldeed aan de eisen om video's van klanten te vergelijken die verschillende schoenen gebruiken. De app bood een naadloze ervaring voor medewerkers, waardoor ze klantprestaties effectief konden analyseren.
cmth3ytci000d01qsvgolc0cu	DLBT	dlbt	The digital library and bibliography of literature in translation and adaptation (DLBT) is a system created and maintained by the University of Vienna. With a stock of about 2,111 volumes and more than 60,000 bibliographic entries in Dutch, German, English, French, Czech, Polish and other languages, it is a useful tool for users and researchers.\nThe system owner takes Erasmus internship students on board to make extend the system.\n\nMy tasks included:\n\n- PHP development in Laravel\n- JavaScript development with JQuery\n- Extending admin features\n- Extending search capabilities with more filters\n- Creating new admin features that merge duplicate data and search for missing data via different APIs\n\nWith new features to improve DLBT's data and advanced search capabilities, the main functionality of the system has been greatly improved. The maintainer of the system and my supervisor were very pleased with my performance and gave me the maximum score.	\N	2026-08-31 10:41:26.034	2026-08-31 10:49:12.481	Universität Wien	Software Developer	https://dlbt.phaidra.org/	2021-05-31 00:00:00	2021-03-01 00:00:00	The digital library and bibliography of literature in translation and adaptation (DLBT) is a system created and maintained by the University of Vienna.	\N	De digitale bibliotheek en bibliografie van literatuur in vertaling en aanpassing (DLBT) is een systeem gemaakt en onderhouden door de universiteit van Wenen.	\nDe digitale bibliotheek en bibliografie van literatuur in vertaling en aanpassing (DLBT) is een systeem gemaakt en onderhouden door de universiteit van Wenen. Met een voorraad van ongeveer 2.111 volumes en meer dan 60.000 bibliografische ingangen in het Nederlands, Duits, Engels, Frans, Tsjechisch, Pools en andere talen, is het een nuttig instrument voor gebruikers en onderzoekers.\nDe eigenaar van het systeem neemt Erasmus stagestudenten aan boord om het systeem uit te breiden.\n\nMijn taken bestonden uit:\n\n- PHP development in Laravel\n- JavaScript development met JQuery\n- Uitbreiden van admin features\n- Uitbreiden van zoekmogelijkheden met meer filters\n- Nieuwe admin features maken die dubbele data samenvoegt en ontbrekende data opzoekt via verschillende API's
cmth4d4ek000q01qst2rbggmx	Sopraco Sharepoint	sopraco	Sopraco, a leading meat trading company, is migrating to SharePoint Online. This transition to the online platform aims to enhance their operational efficiency. By leveraging SharePoint Online, Sopraco can facilitate seamless collaboration, document sharing and information management, optimising business processes and strengthening internal communication within the company.\n\nMy tasks included:\n\n- Writing migration scripts using PowerShell\n- Using ShareGate to transfer data\n- Setting up SharePoint Online structure in cooperation with the customer\n- SharePoint administration\n- Creating custom components and adding them to SharePoint pages\n\nThe migration to SharePoint Online has gone well and the users were able to move forward with the new system.\nIn addition, the new system offered a better structure and new features.	\N	2026-08-31 10:52:33.548	2026-08-31 12:04:01.915	Sopraco Group	SharePoint developer	\N	2022-09-01 00:00:00	2022-07-01 00:00:00	Sopraco, a leading meat trading company, is migrating to SharePoint Online. This transition to the online platform aims to enhance their operational efficiency.	\N	Sopraco, een vooraanstaand vleeshandelbedrijf, migreert naar SharePoint Online. Deze overstap naar het online platform zal hun operationele efficiëntie verbeteren.	Sopraco, een vooraanstaand vleeshandelbedrijf, migreert naar SharePoint Online. Deze overstap naar het online platform zal hun operationele efficiëntie verbeteren. Door gebruik te maken van SharePoint Online kan Sopraco naadloos samenwerken, documenten delen en informatie beheren, wat de bedrijfsprocessen optimaliseert en de communicatie binnen het bedrijf versterkt.\n\nMijn taken bestonden uit:\n\n- Migratiescripts schrijven met PowerShell\n- ShareGate gebruiken voor de overdracht van data\n- SharePoint Online structuur opstellen in samenwerking met de klant\n- SharePoint administratie\n- Custom componenten maken en toevoegen aan SharePoint pagina's\n\nDe migratie naar SharePoint Online is goed verlopen en de gebruikers konden verder met het nieuwe systeem.\nDaarnaast bood het nieuwe systeem ook een betere structuur en nieuwe functies aan.
cmth4n06s001601qso6rkhpdk	Democo templating tool	democo-templating-tool	Democo Group is a company in the construction industry. They had a very outdated templating tool that had become cluttered and wanted to revise it.\n\nMy tasks included:\n\n- Setting up SharePoint for templates\n- Creating a PowerApp that uses SharePoint for its data\n- Writing Azure Function in .NET to process Word documents to the expected format\n- Coordinating with the customer\n\nThe result was a working PowerApp that saved a lot of time and money for many people. One can now enter some values into the application, confirm and a few seconds later get the correct template based on the data entered.	\N	2026-08-31 11:00:14.644	2026-08-31 11:00:14.644	Democo Group	Power Apps developer	\N	2023-05-01 00:00:00	2022-08-01 00:00:00	Democo Group is a company in the construction industry. They had a very outdated templating tool that had become cluttered and wanted to revise it.	\N	Democo Group is een bedrijf in de bouwsector. Ze hadden een erg verouderde templating tool die onoverzichtelijk was geworden en wilden dit graag herzien.	Democo Group is een bedrijf in de bouwsector. Ze hadden een erg verouderde templating tool die onoverzichtelijk was geworden en wilden dit graag herzien.\n\nMijn taken houden in:\n\n- SharePoint opstellen voor templates\n- Maken van een PowerApp die gebruik maakt van SharePoint voor zijn data\n- Azure Function in .NET schrijven om Word documenten te verwerken naar het verwachte formaat\n- Afstemmen met de klant\n\nHet resultaat was een werkende PowerApp die heel wat tijd en geld uitspaarde voor veel mensen. Men kan nu enkele waarden ingeven in de applicatie, bevestigen en enkele seconden later krijgt men de juiste template op basis van de ingevulde data.
cmth45ljq000j01qsumb536gr	Routty	routty	Routty is a SaaS scale-up company. It sells its product, Routty, that can be used to directly and automatically receive, send and process financial data to business applications for matching, approval, archiving and workflow capabilities in a single platform while accelerating control, compliance, efficiency and opportunities.\n\nMy tasks included:\n\n- Front-end development in JavaScript and JQuery\n- Migration from custom JavaScript framework to Angular 13\n- Testing and review of developments\n- UI/UX improvements\n- Server-side communication with PHP\n- Writing migration and upgrade scripts with SQL\n- Small extensions in .NET API\n\nSignificant value was added to the product. The user interface was been transformed, becoming more intuitive, visually appealing and responsive. The application became more efficient after introducing Angular. New features were seamlessly integrated, enhancing user experience and engagement.\nAdditionally, the development team successfully addressed various challenges, ensuring the application is user-friendly and performs efficiently across different browsers, providing users with a seamless and enjoyable experience.	\N	2026-08-31 10:46:42.518	2026-08-31 10:52:54.605	Routty	Frontend product developer	\N	2022-10-05 00:00:00	2021-09-01 00:00:00	Routty is a SaaS scale-up company. It sells its product, Routty, that can be used to directly and automatically receive, send and process financial data to business applications for matching, approval, archiving and workflow capabilities.	\N	Routty is een SaaS scale-up bedrijf. Het verkoopt zijn product Routty, waarmee financiële gegevens rechtstreeks en geautomatiseerd kunnen worden ontvangen.	Routty is een SaaS scale-up bedrijf. Het verkoopt zijn product Routty, waarmee financiële gegevens rechtstreeks en geautomatiseerd kunnen worden ontvangen, verzonden en verwerkt naar bedrijfsapplicaties voor matching, goedkeuring, archivering en workflowmogelijkheden in één enkel platform, terwijl de controle, naleving, efficiëntie en kansen worden versneld.\n\nMijn taken bestonden uit\n\n- Front-end development in JavaScript en JQuery\n- Migratie van custom JavaScript framework naar Angular 13\n- Testing en review van developments\n- UI/UX verbeteringen toebrengen\n- Server-side communicatie met PHP\n- Migratie en upgradescripts schrijven met SQL\n- Kleine uitbreidingen in .NET API\n\nEr is aanzienlijke waarde toegevoegd aan het product. De gebruikersinterface werd getransformeerd en werd intuïtiever, visueel aantrekkelijker en responsiever. De applicatie werkte sneller na het implementeren van Angular. Nieuwe functies werden naadloos geïntegreerd, waardoor de gebruikerservaring en de betrokkenheid werden verbeterd.\nBovendien pakte het ontwikkelingsteam met succes verschillende uitdagingen aan, zodat de applicatie gebruiksvriendelijk is en efficiënt werkt in verschillende browsers, zodat gebruikers een naadloze en prettige ervaring hebben.
cmth4hrb4001001qser2cv44g	GT data migration	gt-migration	Grant Thornton (GT) is originally an American accounting firm, it is the 7th largest accounting firm in the world.\nGT Belgium had crucial data in an old system and wanted to migrate this data to a new system, where some missing data needed to be completed automatically.\nThis migration was done with several Java scripts.\n\nMy tasks included:\n\n- Follow up on the project and discuss next steps\n- Creating Java scripts for migration of data\n- Monitoring performance of migration\n\nThe migration of all data to the new system was a great success, with the added value that all data that still would be stored into the old system, afterwards also would be migrated automatically.	\N	2026-08-31 10:56:09.856	2026-08-31 11:02:14.377	Grant Thornton Belgium	Software consultant	\N	2022-09-01 00:00:00	2022-07-01 00:00:00	Grant Thornton (GT) is originally an American accounting firm, it is the 7th largest accounting firm in the world.\nGT Belgium had crucial data in an old system and wanted to migrate this data to a new system.	\N	Grant Thornton(GT) is een van oorsprong Amerikaans accounting bedrijf, het is het zevende grootste accounting bedrijf in de wereld.\nGT Belgium had cruciale data opgeslagen in een oud systeem en wou deze data migreren naar een nieuw systeem.	Grant Thornton (GT) is een van oorsprong Amerikaans accounting bedrijf, het is het zevende grootste accounting bedrijf in de wereld.\nGT Belgium had cruciale data opgeslagen in een oud systeem en wou deze data migreren naar een nieuw systeem, waar sommige ontbrekende data automatisch aangevuld moesten worden.\nDeze migratie werd uitgevoerd met verschillende Java scripts.\n\nMijn taken houden in:\n\n- Opvolgen van het project en volgende stappen bespreken\n- Java scripts maken voor migratie van data\n- Performantie van migratie monitoren\n\nDe migratie van alle data naar het nieuwe systeem was een groot succes, met als toegevoegde waarde dat alle data die achteraf nog in het oude systeem opgeslagen zou kunnen worden, ook automatisch gemigreerd zou worden.
cmth6wge7001a01qswpyydgqx	DHL M365 migration	dhl-migration365	DHL Belgium and Netherlands was using an old SharePoint 2013 that will no longer be supported by Microsoft. To ensure a smooth migration of all the different SharePoint sites to SharePoint Online, DHL had asked us for consultation, training and assistance.\n\nMy tasks included:\n\n- Project management\n- Communication with stakeholders\n- Resource management and planning\n- Power Automate development follow-up, coaching and validation\nBudget follow-up\n- Planning training on the DHL sites including overnight stays\n- Thinking ahead for next steps in the Microsoft 365 platform\n\nOver several months, we provided DHL employees with the right training and assistance to successfully carry out their migration to SharePoint Online and Microsoft 365.\nA partnership was also established between us and DHL, from which soon another Microsoft training project followed.	\N	2026-08-31 12:03:34.783	2026-08-31 12:04:20.023	DHL	Project manager	\N	2023-09-01 00:00:00	2023-04-01 00:00:00	DHL Belgium and Netherlands was using an old SharePoint 2013 that will no longer be supported by Microsoft.	\N	DHL België en Nederland gebruikte een oude SharePoint 2013 die niet meer ondersteund zou worden door Microsoft.	\N
cmth71skb001f01qsrisbzd0y	TCM Belgium Web	tcm	TCM is a company that focuses on collecting unpaid invoices so that your own company doesn't have to. To follow up these claims (unpaid invoices) internally, a completely custom (Java) software package was written, on which the company is completely dependent. Here, some extensions were needed due to new legislations, as well as to improve the overall workflow.\n\nMy tasks included:\n\n- Extending existing Java system in Java\n- Automating long-winded processes\n- Improve user experience of long-winded processes\n- Coaching of junior developer on the project\n\nThe requested extensions have been delivered within the deadline, what was important for the legal aspect of TCM.\nIn addition, we were able to implement some of their lower-priority automations and extensions, which made the customer happy and sign up for more extensions.	\N	2026-08-31 12:07:43.835	2026-08-31 12:07:43.835	TCM Belgium	Software developer	\N	2023-09-01 00:00:00	2023-07-01 00:00:00	TCM is a company that focuses on collecting unpaid invoices so that your own company doesn't have to. To follow up these claims (unpaid invoices) internally, a completely custom (Java) software package was written...	\N	TCM is een bedrijf dat zich focust op het innen van onbetaalde facturen, zodat je eigen bedrijf dit niet moet doen.\nOm deze claims (onbetaalde facturen) intern op te volgen is een volledig custom softwarepakket geschreven...	TCM is een bedrijf dat zich focust op het innen van onbetaalde facturen, zodat je eigen bedrijf dit niet moet doen.\nOm deze claims (onbetaalde facturen) intern op te volgen is een volledig custom softwarepakket geschreven in Java, waar het bedrijf volledig van afhankelijk is. Er waren enkele uitbreidingen nodig door nieuwe wetgevingen, alsook om de algemene workflow te verbeteren.\n\nMijn taken:\n\n- Uitbreiden van bestaande Java systeem in Java\n- Automatiseren van langdradige processen\n- User experience van langdradige processen verbeteren\n- Coaching van junior developer op het project\n\nDe gevraagde uitbreidingen waren binnen de termijn opgeleverd, wat belangrijk was voor het legaal aspect van TCM.\nDaarnaast hebben we ook enkele van hun minder prioritaire automatisaties en uitbreidingen kunnen doorvoeren, waardoor de klant gelukkig was en heeft getekend voor meer uitbreidingen.
cmth75t4l001j01qsfu7tofh9	Pioneer Europe Lotus Notes support	pioneer	Pioneer Europe specialises in digital entertainment products. The backbone of their IT infrastructure was created in HCL Notes, a robust but outdated system. Due to a lack of knowledge of this system, there was a need for external consultancy.\n\nMy tasks included:\n\n- Consultancy in HCL Notes in Microsoft 365\n- End-user support\n- Developments and extensions of Notes applications\n- Exports of data from HCL Notes\n\nAfter working with Pioneer for a year and a half, I established a good relationship with them and a partnership was formed. In addition, they were also more than satisfied with my services.	\N	2026-08-31 12:10:51.189	2026-08-31 12:10:51.189	Pioneer Europe	Consultant	\N	2023-10-01 00:00:00	2022-06-01 00:00:00	Pioneer Europe specialises in digital entertainment products. The backbone of their IT infrastructure was created in HCL Notes, a robust but outdated system. Due to a lack of knowledge of this system, there was a need for external consultancy.	\N	Pioneer Europe is gespecialiseerd in digitale entertainment producten. De backbone van hun IT-infrastructuur is gemaakt in HCL Notes, een robuust maar verouderd systeem. Door een gebrek aan kennis van dit systeem was er nood aan externe consultancy.	Pioneer Europe is gespecialiseerd in digitale entertainment producten. De backbone van hun IT-infrastructuur is gemaakt in HCL Notes, een robuust maar verouderd systeem. Door een gebrek aan kennis van dit systeem was er nood aan externe consultancy.\n\n- Consultancy in HCL Notes in Microsoft 365\n- End-user en admin support\n- Ontwikkelingen en uitbreidingen van Notes applicaties\n- Exports van data uit HCL Notes\n\nNa anderhalf jaar samen te werken met Pioneer heb ik een goede relatie opgebouwd met hun en is er een partnership ontstaan. Daarnaast was men ook meer dan tevreden van mijn diensten.
cmth7bnzz001l01qsgsd1xf6h	SQAS 2.0	cefic-sqas	Safety and Quality Assessment for Sustainability (SQAS) is a system initiated by the European Chemical Industry Council (Cefic) to evaluate the quality, safety, security and environmental performance of logistics service providers and chemical distributors.\nThese assessments are done through the SQAS software built in Angular 4, that was outdated and needed a revision.\n\nMy tasks included:\n\n- Code migration from Angular 4 to a custom Embedded Power Pages component\n- Development of SQAS Members site in Power Pages\n- Development of SQAS Software in TypeScript and SCSS\n- Development of PowerBi Embedded and extensions in React\n- Data migration from SQL Server to Dataverse with Power Query\n- Creating Dataverse Model Driven Admin App\n- Creating Power Automate flows to automate underlying processes\n- End user support for the new system\n\nThe new SQAS system is live and being used throughout Europe. The new system provides an easier experience for all users.	\N	2026-08-31 12:15:24.479	2026-08-31 12:15:24.479	Cefic	Power Pages developer	https://sqas.org/	2023-10-01 00:00:00	2022-09-01 00:00:00	Safety and Quality Assessment for Sustainability (SQAS) is a system initiated by the European Chemical Industry Council (Cefic) to evaluate the quality, safety, security and environmental performance of logistics service providers and chemical distributor	\N	Safety and Quality Assessment for Sustainability (SQAS) is een systeem dat is opgezet door de European Chemical Industry Council (Cefic) om de kwaliteit, veiligheid, beveiliging en milieuprestaties van logistieke dienstverleners en chemische distributeurs	Safety and Quality Assessment for Sustainability (SQAS) is een systeem dat is opgezet door de European Chemical Industry Council (Cefic) om de kwaliteit, veiligheid, beveiliging en milieuprestaties van logistieke dienstverleners en chemische distributeurs te evalueren.\nDeze beoordelingen worden gedaan met behulp van de SQAS-software gemaakt in Angular 4, deze was verouderd was en moest worden herzien.\n\nMijn taken hielden in:\n\n- Code migratie van Angular 4 naar een zelfgeschreven Embedded Power Pages component\n- Development van SQAS Members site in Power Pages\n- Development van SQAS Software in TypeScript en SCSS\n- Development van PowerBi Embedded en extensies in React\n- Data migratie van SQL Server naar Dataverse met Power Query\n- Dataverse Model Driven Admin App maken\n- Power Automate flows maken voor automatiseren van achterliggende processen\n- End user support voor het nieuwe systeem\n\nHet nieuwe SQAS systeem staat live en wordt gebruikt doorheen heel Europa. Het nieuwe systeem zorgt voor een makkelijkere ervaring voor alle gebruikers.
cmth7w6ov001p01qs647j4sc4	Vitals Design System	vitals	The first MyHealth Design System (DS), which I originally set up for the limited scope of the development of the MijnGezondheid website, is in need of an update. Since the DS is now used by various parties (Sopra Steria, Smals, VIDIS, UHMEP), we need a more advanced DS that meets the requirements of all parties.\n\nMy tasks included:\n\n- Negotiate with stakeholders on what should and should not be included in the overall design system.\n- Co-create a design system that meets the requirements of all stakeholders.\n- Ensure UX best practices for both mobile and desktop use of components.\n- Bring AI expertise to the team and implement toolkits in codebases.\n- Oversee the implementation of the design system across various applications.	\N	2026-08-31 12:31:21.823	2026-08-31 12:31:21.823	FOD Health	Frontend architect	https://github.com/smals-belgium/shared-myhealth	2026-09-01 00:00:00	2026-05-01 00:00:00	The first MyHealth Design System (DS), which I originally set up for the limited scope of the development of the MijnGezondheid website, is in need of an update.	\N	Het eerste MyHealth Design System (DS), initieel opgezet door mij voor de gelimiteerde scope van de development van de MijnGezondheid website, is toe aan vernieuwing toe.	Het eerste MyHealth Design System (DS), initieel opgezet door mij voor de gelimiteerde scope van de development van de MijnGezondheid website, is toe aan vernieuwing toe. Doordat het DS nu gebruikt word door verschillende parijen (Sopra Steria, Smals, VIDIS, UHMEP), hebben we een meer geavanceerd DS nodig die voldoet aan de ijsen van alle partijen.\n\n- Onderhandelen met partijen over wat wel en niet in het globale design system komt.\n- Co-creatie van een design systeem dat voldoet aan de eisen van alle partijen.\n- UX safeguarden voor zowel mobiel -als desktop gebruik van componenten \n- AI-expertise in het team brengen en toolsets implementeren in codebases.\n- Overzien van de implementatie van het design systeem in verschillende applicaties
cmth8b5at001v01qsy6r3wwad	Thomas & Piron 3.0: New websites	tp-new	The old T&P website was very outdated, and built upon a terrible codebase by a 3rd party. After maintaining and improving the website for years, we finally decided to start from scratch to build a new, clean Drupal website. This Drupal site would fetch its most important data from a .NET backend, before indexing and dispalying it through Drupal. The new website is according to Drupal best practices.\n\nMy tasks included:\n\n- Main responsible for front-end and UX\n- Mentoring front-end developers within the project\n- Developing a new React and Drupal integrated front-end structure\n- Ensuring compliance with accessibility best practices\n- Monitoring performance and optimising code\n- Developing a component-based website architecture	\N	2026-08-31 12:42:59.861	2026-08-31 12:47:09.055	Thomas & Piron	Lead frontend developer	https://thomas-piron.eu/	2026-09-01 00:00:00	2025-12-01 00:00:00	The old T&P website was very outdated, and built upon a terrible codebase by a 3rd party. After maintaining and improving the website for years, we finally decided to start from scratch to build a new, clean Drupal site.	\N	De oude T&P-website was erg verouderd en gebouwd op basis van een slechte codebasis van een externe partij. Nadat we de website jarenlang hadden onderhouden en verbeterd, hebben we uiteindelijk besloten om helemaal opnieuw te beginnen.	De oude T&P-website was erg verouderd en gebouwd op basis van een slechte codebasis van een externe partij. Nadat we de website jarenlang hadden onderhouden en verbeterd, hebben we uiteindelijk besloten om helemaal opnieuw te beginnen en een nieuwe, strakke Drupal-website te bouwen. Deze Drupal-site haalt de belangrijkste gegevens op uit een .NET-backend, waarna deze via Drupal worden geïndexeerd en weergegeven. De nieuwe website voldoet aan de best practices van Drupal\n\nMijn taken bestonden uit:\n\n- Primaire verantwoordelijke voor front-end en UX\n- Begeleiden van front-end developers binnen het project\n- Uitbouwen van nieuwe React- en Drupal integrated front-end structuur\n- Accessibility best-practices bewaken\n- Performantie en (code) optimizatie bewaken\n- Uitbouwen van component-based website architectuur
cmth8y9xp001y01qslx1aiafy	MyHealth Belgium	myhealth	MyHealth is the online health portal where a person's health data are centralised. It is a single gateway to all relevant health information: the summary medical record kept by the general practitioner, the data recorded and shared by healthcare providers in hospitals, therapeutic relationships, general health information, etc.\nOn the one hand, this mission concerns the applicative support of the application in which questions from citizens have to be handled and corresponding bugs have to be solved.\nOn the other hand, it concerns the further expansion of the portal with new functionalities and possibilities in which data must be exchanged with various partners via APIs and web components.\n\nMy tasks included:\n\n- Converting Figma design to reality in Angular 17\n- Maintaining Angular application from version 17 to 22\n- Create a reusable public design system that can be used by third parties via NPM\n- Setting up a scalable Angular architecture to build a growing application\n- Focus on user-friendly design and accessibility\n- Storybook documentation\n- Lead and coaching in frontend applications and libraries\n- Creating and maintaining public component libraries	\N	2026-08-31 13:00:58.957	2026-08-31 13:03:58.329	FOD Health	Lead frontend developer	https://www.myhealth.belgium.be/	2026-09-01 00:00:00	2023-11-01 00:00:00	MyHealth is the online health portal where a person's health data are centralised. It is a single gateway to all relevant health information.	\N	Mijngezondheid is het online gezondheidsportaal waarop verschillende persoonlijke gegevens over iemands gezondheid centraal beschikbaar zijn. Het is één toegangspoort tot alle relevante gezondheidsinformatie.	Mijngezondheid is het online gezondheidsportaal waarop verschillende persoonlijke gegevens over iemands gezondheid centraal beschikbaar zijn. Het is één toegangspoort tot alle relevante gezondheidsinformatie: het beknopt medisch dossier dat de huisarts bewaart, de gegevens die zorgverleners in ziekenhuizen registreren en delen, de therapeutische relaties, algemene gezondheidsinformatie, enz.\nEnerzijds betreft deze opdracht de applicatieve support van de toepassing waarbij vragen van burgers behandeld en bijhorende bugs opgelost moeten worden.\nAnderzijds gaat het over het verder uitbreiden van het portaal met nieuwe functionaliteiten en mogelijkheden waarbij er met diverse partners via API's en webcomponenten data uitgewisseld moet worden.\n\nMijn taken houden in:\n\n- Omzetten van Figma design naar realiteit in Angular 17\n- Onderhouden van Angular applicatie van versie 17 tot 22\n- Een herbruikbaar publiek design systeem maken dat via NPM kan gebruikt worden door derden\n- Een schaalbare Angular architectuur opzetten om een groeiende applicatie op te bouwen\n- Focus op user-friendly design en toegankelijkheid\n- Storybook documentatie\n- Leiden en coachen in frontend applicaties en libraries\n- Onderhouden van publieke component libraries
cmth9tli0002201qsem25hbba	CM Gezonde Buurt (Healthy Neighbourhood)	gezonde-buurt	LCM is the biggest social security and health fund in Belgium.\nSopra Steria provides SLA support for the public LCM websites that are built with Drupal and Acquia. We are a direct partner of Acquia and are implementing technically more complex features of the platform for LCM.\nAs part of the SLA, I set up a new subsite to their site called Gezonde Buurt (Healthy Neighbourhood).\n\nMy tasks included:\n\n- Setting up new Drupal sites\n- Setting up Drupal site structures and search API\n- Building web components with Acquia Site Studio	\N	2026-08-31 13:25:20.28	2026-08-31 13:25:20.28	LCM	Frontend developer	https://cm.be/gezonde-buur	2024-09-01 00:00:00	2024-06-01 00:00:00	LCM is the biggest social security and health fund in Belgium.\nSopra Steria provides SLA support for the public LCM websites that are built with Drupal and Acquia.	\N	LCM is het grootste sociale zekerheids- en gezondheidsfonds in België.\nSopra Steria biedt SLA-ondersteuning voor LCM's publieke websites die zijn gebouwd met Drupal en Acquia.	LCM is het grootste sociale zekerheids- en gezondheidsfonds in België.\nSopra Steria biedt SLA-ondersteuning voor LCM's publieke websites die zijn gebouwd met Drupal en Acquia. We zijn een directe partner van Acquia en implementeren technisch complexere functies van het platform voor LCM.\nAls onderdeel van de SLA heb ik een nieuwe subsite opgezet voor hun site genaamd Gezonde Buurt.\n\nMijn taken houden in:\n\n- 
cmth9wxz8002601qsh1jkny76	Agoria Assistant	agoria-assistant	Agoria wanted to open up an AI chatbot to search through their website. The website in question was made in Drupal, while the chatbot was to be a React app integrated into the Drupal environment.\nThe API that addresses the React app was created by a third party.\n\nMy tasks included:\n\n- Full development of the React app and integration into Drupal\n- Matching requirements of .NET API created by third party vendor\n- Sync of translations between Drupal and React app\n\nThanks to our flexibility, we were able to meet the deadlines set by the customer time and again. We finally went live with the chatbot for members in December, the customer was very satisfied with the delivered result and there will most likely be further extensions for the chatbot.	\N	2026-08-31 13:27:56.42	2026-08-31 13:27:56.42	Agoria	Lead frontend developer	\N	2024-12-01 00:00:00	2024-09-01 00:00:00	Agoria wanted to open up an AI chatbot to search through their website. The website in question was made in Drupal, while the chatbot was to be a React app integrated into the Drupal environment.	\N	Agoria wou een AI chatbot openstellen om te zoeken door hun website. De website in kwestie was gemaakt in Drupal, terwijl de chatbot een React app zou moeten worden die in de Drupal omgeving geïntegreerd wordt.	Agoria wou een AI chatbot openstellen om te zoeken door hun website. De website in kwestie was gemaakt in Drupal, terwijl de chatbot een React app zou moeten worden die in de Drupal omgeving geïntegreerd wordt.\nDe API die de React app aanspreekt, werd gemaakt door een derde partij.\n\nMijn taken houden in:\n\n- Volledige development van de React app en integratie in Drupal\n- Afstemmen vereisten van .NET API gemaakt door derde partij\n- Sync van translaties tussen Drupal en React app\n\nDoor onze flexibiliteit konden we keer op keer de deadlines gezet door de klant halen. We zijn uiteindelijk live gegaan met de chatbot voor members in december, de klant was erg tevreden over het opgeleverde resultaat en er komen hoogstwaarschijnlijk nog uitbreidingen voor de chatbot.
cmtha0wuo002801qsttpg6vk0	Thomas & Piron: websites maintenance	tp	Thomas & Piron has an extensive curriculum of websites maintained by Sopra Steria. Most of these websites are built in Drupal that uses an integrated React application to handle technically more complex issues.\nSince 2025, we have been analysing and creating a new website.\n\nMy tasks included:\n\n- Maintain and extend existing features in React and Drupal\n- Developing new features in React and Drupal\n- Providing support in case of incidents\n- Promoting web application continuity and accessibility	\N	2026-08-31 13:31:01.584	2026-08-31 13:31:01.584	Thomas & Piron	Lead frontend developer	\N	2026-08-01 00:00:00	2024-09-01 00:00:00	Thomas & Piron has an extensive curriculum of websites maintained by Sopra Steria. Most of these websites are built in Drupal that uses an integrated React application.	\N	Thomas & Piron heeft een uitgebreid curriculum aan websites die onderhouden worden door Sopra Steria. Het merendeel van deze websites zijn gebouwd in Drupal dat gebruik maakt van een geïntegreerde React applicatie.	Thomas & Piron has an extensive curriculum of websites maintained by Sopra Steria. Most of these websites are built in Drupal that uses an integrated React application to handle technically more complex issues.\nSince 2025, we have been analysing and creating a new website.\n\nMijn taken hielden in:\n\n- Maintain and extend existing features in React and Drupal\n- Developing new features in React and Drupal\n- Providing support in case of incidents\n- Promoting web application continuity and accessibility
\.


--
-- Data for Name: Resume; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Resume" (id, "fileName", "objectKey", "mimeType", "fileSize", "uploadedAt") FROM stdin;
cmt1mgkmp00013gpqp9w0gk1h	sample.pdf	resume/22ede0f8-bcc6-4eab-9cd5-aaabce7bc65f.pdf	application/pdf	18810	2026-08-20 14:34:48.817
\.


--
-- Data for Name: ResumeDownload; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."ResumeDownload" (id, "resumeId", "createdAt") FROM stdin;
\.


--
-- Data for Name: Role; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Role" (id, "jobTitle", "organizationId", location, "employmentType", "startDate", "endDate", "createdAt", "updatedAt", "descriptionEn", "descriptionNl") FROM stdin;
cmt04byto0007o7pq4vo54svo	Consultant	cmt04byso0005o7pqri3jv4cw	Leuven, Belgium	FULL_TIME	2022-05-01 00:00:00	2023-10-01 00:00:00	2026-08-19 13:19:34.668	2026-08-19 13:19:34.668	\N	\N
cmt04cza7000bo7pq5zhgxnc2	Frontend Product Developer	cmt04cz980009o7pqbzt3kaz1	Kontich, Belgium	FULL_TIME	2021-09-01 00:00:00	2021-05-01 00:00:00	2026-08-19 13:20:21.919	2026-08-19 13:20:21.919	\N	\N
cmt04e8z4000fo7pqhx8nj4iv	Software Developer	cmt04e8y6000do7pq023jk1v2	Vienna, Austria	INTERNSHIP	2021-03-01 00:00:00	2021-06-01 00:00:00	2026-08-19 13:21:21.136	2026-08-19 13:21:21.136	\N	\N
cmt04glyk000jo7pq9xk6kfef	Frontend Developer	cmt04glxk000ho7pqx5zog8hl	Oevel, Belgium	SEASONAL	2019-10-01 00:00:00	2021-02-01 00:00:00	2026-08-19 13:23:11.276	2026-08-19 13:51:31.91	\N	\N
cmt00wcpg0005wbpq2jc739sk	Lead frontend developer	cmt00v4wa0000wbpq4psbs8q5	Brussels, Belgium	FULL_TIME	2025-01-01 00:00:00	\N	2026-08-19 11:43:27.316	2026-08-19 13:54:01.312	\N	\N
cmt00v4xb0002wbpqzcd1qi0q	Frontend developer	cmt00v4wa0000wbpq4psbs8q5	Brussels, Belgium	FULL_TIME	2023-11-06 00:00:00	2024-12-31 00:00:00	2026-08-19 11:42:30.575	2026-08-19 13:54:03.896	\N	\N
cmt04aq6p0002o7pqps2ciclz	Digital Accessibility Leader for Belux	cmt00v4wa0000wbpq4psbs8q5	Brussels, Belgium	FULL_TIME	2025-06-01 00:00:00	\N	2026-08-19 13:18:36.817	2026-08-20 10:52:50.635	Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed efficitur nibh facilisis arcu pellentesque tincidunt quis id risus. Suspendisse mi dui, bibendum a commodo ut, bibendum et urna. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Donec vehicula orci nec sagittis finibus. Vestibulum malesuada, lectus at consequat interdum, erat odio pretium justo, quis maximus turpis erat ut diam. Cras sed pharetra sem. Nam gravida tempor tortor commodo tincidunt.\n\nDonec elementum finibus leo in finibus. Pellentesque ornare eu ipsum vitae pellentesque. Maecenas finibus nunc tristique pretium tempor. Aliquam magna mi, consequat et aliquam eu, condimentum volutpat quam. Praesent at lacus ultricies, efficitur massa ac, tincidunt metus. Aenean elit nisl, scelerisque sit amet dolor et, pharetra vestibulum metus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.	\N
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Session" (id, "tokenHash", "githubUserId", "expiresAt", "createdAt", "displayName", "avatarUrl") FROM stdin;
\.


--
-- Data for Name: Skill; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Skill" (id, name) FROM stdin;
cmsyqzhke0001i3pqpyts67d9	angular
cmsyqzhl00002i3pq8p0sq7ep	rxjs
cmsyqzhl10003i3pqvr31azf0	ui design
cmsyqzhl30004i3pqbz4ks4mu	ux research
cmsyqzhl40005i3pqq9ajgyx6	design systems
cmt04aq6z0003o7pqbxi2o1eh	a11y
cmt04glyt000ko7pq80jgar7z	.net
cmt1bfez00003ylpqahrfad5k	drupal
cmth28pkv000201qs1wlz5byp	flutter
cmth28pkz000301qso1xj68ih	frontend development
cmth2igxr000701qsjivpstd3	ngrx
cmth2igxs000801qsjswqgweh	azure
cmth2jznn000b01qsazxo8811	mobile development
cmth3ytcl000e01qsz343d8jl	php
cmth3ytcn000f01qsa8b5a277	laravel
cmth3ytcp000g01qselx4g4w9	javascript
cmth45ljx000k01qsp7n7ea2p	testing
cmth45ljz000l01qs6msj18lq	scrum
cmth45lk3000m01qsj9zhi53f	sql
cmth4d4eq000r01qsqgc84n2b	sharepoint
cmth4d4ev000s01qsur1d8x0l	powershell
cmth4d4ex000t01qsvryh2t88	react
cmth4d4f0000u01qshqpmv5is	power automate
cmth4d4f3000v01qspu2gr11s	sharegate
cmth4d4f6000w01qsn94murnr	typescript
cmth4hrb8001101qs6wxp4o1h	project management
cmth4hrbb001201qs1whcixtx	java
cmth4hrbd001301qszwjy3bvr	lotus notes
cmth4hrbe001401qsrlbb2143	consultancy
cmth4n06v001701qsl533auxa	power apps
cmth71skg001g01qsg148yigp	coaching
cmth71sks001h01qswn5y12l0	unit testing
cmth7bo09001m01qsyzszwptc	power pages
cmth7bo0b001n01qsdw1p2aos	power bi
cmth7w6p4001q01qs2k9cyf1z	lit
cmth7w6p9001r01qs7nvpl3r3	architecture
cmth9tli2002301qsjj5xehas	acquia
cmth9tli9002401qsllq0e6nw	docker
\.


--
-- Data for Name: _ProjectToSkill; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."_ProjectToSkill" ("A", "B") FROM stdin;
cmth71skb001f01qsrisbzd0y	cmth71skg001g01qsg148yigp
cmth71skb001f01qsrisbzd0y	cmth3ytcp000g01qselx4g4w9
cmth71skb001f01qsrisbzd0y	cmth4hrbb001201qs1whcixtx
cmth71skb001f01qsrisbzd0y	cmth45lk3000m01qsj9zhi53f
cmth71skb001f01qsrisbzd0y	cmth71sks001h01qswn5y12l0
cmth71skb001f01qsrisbzd0y	cmsyqzhl30004i3pqbz4ks4mu
cmth75t4l001j01qsfu7tofh9	cmth4hrbd001301qszwjy3bvr
cmth75t4l001j01qsfu7tofh9	cmth4hrbe001401qsrlbb2143
cmth7bnzz001l01qsgsd1xf6h	cmsyqzhke0001i3pqpyts67d9
cmth7bnzz001l01qsgsd1xf6h	cmth4d4ex000t01qsvryh2t88
cmth7bnzz001l01qsgsd1xf6h	cmth2igxs000801qsjswqgweh
cmth2igxe000601qsbgblqpjj	cmsyqzhke0001i3pqpyts67d9
cmth2igxe000601qsbgblqpjj	cmt04glyt000ko7pq80jgar7z
cmth2igxe000601qsbgblqpjj	cmsyqzhl10003i3pqvr31azf0
cmth2igxe000601qsbgblqpjj	cmth2igxr000701qsjivpstd3
cmth2igxe000601qsbgblqpjj	cmth2igxs000801qsjswqgweh
cmth7bnzz001l01qsgsd1xf6h	cmth4d4f0000u01qshqpmv5is
cmth7bnzz001l01qsgsd1xf6h	cmth4n06v001701qsl533auxa
cmth7bnzz001l01qsgsd1xf6h	cmth7bo09001m01qsyzszwptc
cmth28pkq000101qsl4k9cio8	cmt04glyt000ko7pq80jgar7z
cmth28pkq000101qsl4k9cio8	cmth28pkv000201qs1wlz5byp
cmth28pkq000101qsl4k9cio8	cmth2jznn000b01qsazxo8811
cmth7bnzz001l01qsgsd1xf6h	cmth7bo0b001n01qsdw1p2aos
cmth7bnzz001l01qsgsd1xf6h	cmth71skg001g01qsg148yigp
cmth7bnzz001l01qsgsd1xf6h	cmt04glyt000ko7pq80jgar7z
cmth7bnzz001l01qsgsd1xf6h	cmth4d4f6000w01qsn94murnr
cmth7bnzz001l01qsgsd1xf6h	cmsyqzhl10003i3pqvr31azf0
cmth7bnzz001l01qsgsd1xf6h	cmth45lk3000m01qsj9zhi53f
cmth7w6ov001p01qs647j4sc4	cmsyqzhke0001i3pqpyts67d9
cmth7w6ov001p01qs647j4sc4	cmth7w6p4001q01qs2k9cyf1z
cmth7w6ov001p01qs647j4sc4	cmsyqzhl40005i3pqq9ajgyx6
cmth7w6ov001p01qs647j4sc4	cmsyqzhl10003i3pqvr31azf0
cmth7w6ov001p01qs647j4sc4	cmsyqzhl30004i3pqbz4ks4mu
cmth7w6ov001p01qs647j4sc4	cmth7w6p9001r01qs7nvpl3r3
cmth3ytci000d01qsvgolc0cu	cmth3ytcl000e01qsz343d8jl
cmth3ytci000d01qsvgolc0cu	cmth3ytcn000f01qsa8b5a277
cmth3ytci000d01qsvgolc0cu	cmth3ytcp000g01qselx4g4w9
cmth8b5at001v01qsy6r3wwad	cmt1bfez00003ylpqahrfad5k
cmth8b5at001v01qsy6r3wwad	cmth4d4f6000w01qsn94murnr
cmth8b5at001v01qsy6r3wwad	cmsyqzhl30004i3pqbz4ks4mu
cmth8b5at001v01qsy6r3wwad	cmsyqzhl10003i3pqvr31azf0
cmth8b5at001v01qsy6r3wwad	cmt04glyt000ko7pq80jgar7z
cmth8b5at001v01qsy6r3wwad	cmth71skg001g01qsg148yigp
cmth8b5at001v01qsy6r3wwad	cmth3ytcl000e01qsz343d8jl
cmth45ljq000j01qsumb536gr	cmth3ytcp000g01qselx4g4w9
cmth45ljq000j01qsumb536gr	cmsyqzhke0001i3pqpyts67d9
cmth45ljq000j01qsumb536gr	cmth45ljx000k01qsp7n7ea2p
cmth45ljq000j01qsumb536gr	cmth45ljz000l01qs6msj18lq
cmth45ljq000j01qsumb536gr	cmsyqzhl10003i3pqvr31azf0
cmth45ljq000j01qsumb536gr	cmth3ytcl000e01qsz343d8jl
cmth45ljq000j01qsumb536gr	cmth45lk3000m01qsj9zhi53f
cmth45ljq000j01qsumb536gr	cmt04glyt000ko7pq80jgar7z
cmth8y9xp001y01qslx1aiafy	cmt04aq6z0003o7pqbxi2o1eh
cmth4n06s001601qso6rkhpdk	cmth4n06v001701qsl533auxa
cmth4n06s001601qso6rkhpdk	cmth2igxs000801qsjswqgweh
cmth4n06s001601qso6rkhpdk	cmth4d4eq000r01qsqgc84n2b
cmth4n06s001601qso6rkhpdk	cmth4d4f0000u01qshqpmv5is
cmth4n06s001601qso6rkhpdk	cmt04glyt000ko7pq80jgar7z
cmth4n06s001601qso6rkhpdk	cmsyqzhl30004i3pqbz4ks4mu
cmth4n06s001601qso6rkhpdk	cmth4hrb8001101qs6wxp4o1h
cmth4hrb4001001qser2cv44g	cmth4hrb8001101qs6wxp4o1h
cmth4hrb4001001qser2cv44g	cmth4hrbb001201qs1whcixtx
cmth4hrb4001001qser2cv44g	cmth4hrbd001301qszwjy3bvr
cmth4hrb4001001qser2cv44g	cmth4hrbe001401qsrlbb2143
cmth8y9xp001y01qslx1aiafy	cmsyqzhke0001i3pqpyts67d9
cmth8y9xp001y01qslx1aiafy	cmth7w6p9001r01qs7nvpl3r3
cmth8y9xp001y01qslx1aiafy	cmth71skg001g01qsg148yigp
cmth8y9xp001y01qslx1aiafy	cmsyqzhl40005i3pqq9ajgyx6
cmth4d4ek000q01qst2rbggmx	cmth4d4eq000r01qsqgc84n2b
cmth4d4ek000q01qst2rbggmx	cmth4d4ev000s01qsur1d8x0l
cmth4d4ek000q01qst2rbggmx	cmth4d4ex000t01qsvryh2t88
cmth4d4ek000q01qst2rbggmx	cmth4d4f0000u01qshqpmv5is
cmth4d4ek000q01qst2rbggmx	cmth4d4f3000v01qspu2gr11s
cmth4d4ek000q01qst2rbggmx	cmth4d4f6000w01qsn94murnr
cmth8y9xp001y01qslx1aiafy	cmsyqzhl00002i3pq8p0sq7ep
cmth8y9xp001y01qslx1aiafy	cmsyqzhl30004i3pqbz4ks4mu
cmth8y9xp001y01qslx1aiafy	cmsyqzhl10003i3pqvr31azf0
cmth9tli0002201qsem25hbba	cmth9tli2002301qsjj5xehas
cmth6wge7001a01qswpyydgqx	cmth4hrb8001101qs6wxp4o1h
cmth6wge7001a01qswpyydgqx	cmth4d4eq000r01qsqgc84n2b
cmth6wge7001a01qswpyydgqx	cmth4n06v001701qsl533auxa
cmth6wge7001a01qswpyydgqx	cmth4d4f0000u01qshqpmv5is
cmth9tli0002201qsem25hbba	cmt1bfez00003ylpqahrfad5k
cmth9tli0002201qsem25hbba	cmt04aq6z0003o7pqbxi2o1eh
cmth9tli0002201qsem25hbba	cmth3ytcl000e01qsz343d8jl
cmth9tli0002201qsem25hbba	cmth9tli9002401qsllq0e6nw
cmth9wxz8002601qsh1jkny76	cmth4d4ex000t01qsvryh2t88
cmth9wxz8002601qsh1jkny76	cmt04aq6z0003o7pqbxi2o1eh
cmth9wxz8002601qsh1jkny76	cmth3ytcl000e01qsz343d8jl
cmth9wxz8002601qsh1jkny76	cmt1bfez00003ylpqahrfad5k
cmtha0wuo002801qsttpg6vk0	cmt1bfez00003ylpqahrfad5k
cmtha0wuo002801qsttpg6vk0	cmth4d4ex000t01qsvryh2t88
cmtha0wuo002801qsttpg6vk0	cmt04aq6z0003o7pqbxi2o1eh
cmtha0wuo002801qsttpg6vk0	cmth4hrbe001401qsrlbb2143
cmtha0wuo002801qsttpg6vk0	cmsyqzhl30004i3pqbz4ks4mu
cmtha0wuo002801qsttpg6vk0	cmsyqzhl10003i3pqvr31azf0
cmtha0wuo002801qsttpg6vk0	cmth3ytcp000g01qselx4g4w9
\.


--
-- Data for Name: _RoleToSkill; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."_RoleToSkill" ("A", "B") FROM stdin;
cmt04glyk000jo7pq9xk6kfef	cmsyqzhke0001i3pqpyts67d9
cmt04glyk000jo7pq9xk6kfef	cmt04glyt000ko7pq80jgar7z
cmt04aq6p0002o7pqps2ciclz	cmt04aq6z0003o7pqbxi2o1eh
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
371d6aee-6c05-431d-8b77-e776f7e54da5	7dc34aaa6dae9649d366c954534165aa8998fd1e2c7217b6c663aca58e5a7d5d	2026-08-20 09:14:30.813451+00	20260820120000_add_role_description	\N	\N	2026-08-20 09:14:30.809524+00	1
c38fe54c-63c7-4f7d-ace7-821c9fccca7b	eacbfa8e36ed19230a74190552636fd0c6d8550825db3c30e5426804cb070018	2026-08-14 09:19:08.325886+00	20260814091908_init	\N	\N	2026-08-14 09:19:08.313197+00	1
de549956-d520-4e22-a145-efc2843e1bf5	ebe66dab13fe3c3d51885364e2884ffdc7dad1a889db1b1f2e5a8ecc26c44afd	2026-08-17 07:06:07.435101+00	20260817070607_add_contact_messages	\N	\N	2026-08-17 07:06:07.419633+00	1
eb69e496-7d00-4659-aa19-747cb47d34f5	fa5c95ec0374bac6633db52b983458540ccc8c8986a5ce05d8837d507573f709	2026-08-17 07:06:17.364589+00	20260817070617_add_project_skills_client_role_liveurl	\N	\N	2026-08-17 07:06:17.328314+00	1
0457f4ce-30ce-4306-90d7-9f81f546366f	9f86a09fde7768f795d47469f759c611856ddb2356df35c4556f28b593e3b87a	2026-08-20 13:27:01.513784+00	20260820132701_add_project_image_object_key	\N	\N	2026-08-20 13:27:01.509044+00	1
2a26e5e5-6408-4c15-93b3-f58546f1b654	30225d36fd7e5ca8a79d53d57c0b4128cd582be15cf9f60fb88c9ad696044c5b	2026-08-17 07:25:38.051336+00	20260817072538_add_project_start_end_date	\N	\N	2026-08-17 07:25:38.046251+00	1
73255080-199a-4fe8-af0e-bb5001e18518	c9aa04c19fe7e05bf90fee6643b122b9e061484dbec6826111e275644ed56308	2026-08-17 07:41:02.539461+00	20260817074102_add_organizations_and_roles	\N	\N	2026-08-17 07:41:02.510323+00	1
fa85093f-25a4-4ba5-b99f-b2be7c8c3eaf	8753d18039bfea1a3248c2eb1c759fbca67eb6f37a69fde871ef740df0cf7c42	2026-08-17 07:57:24.359851+00	20260817075724_add_feature_flags	\N	\N	2026-08-17 07:57:24.311814+00	1
33292875-5908-4d66-89d1-dc0928c7a657	dde501481fa88edcaa5f21086a98911877c8b8dcae55a972219cc6dfddcc3104	2026-08-21 07:25:05.579541+00	20260821072505_add_organization_logo_object_key	\N	\N	2026-08-21 07:25:05.575186+00	1
aefb7db4-bec5-480f-9aea-70567d8e5f81	fa79e3574271ba6d91d768cf46f6b4da1e597611bb93f15df68d85dd84394084	2026-08-18 07:16:22.658963+00	20260818120000_add_session_profile_metadata	\N	\N	2026-08-18 07:16:22.651991+00	1
34f8b96e-0501-4b99-8c6b-9ab413155590	c32ff57a06b1042361993b452817e841313aa2f2d6105a08028893fe5f0a4790	2026-08-18 08:01:27.485459+00	20260818080127_add_contact_message_organization	\N	\N	2026-08-18 08:01:27.480331+00	1
2e5b0a21-86b2-4dbc-9d64-ec2cf6a7711a	d9f456d25c78e77d344f9060647afdd5f28a3ec98a443882b3beb2b9ba18eba7	2026-08-18 08:12:11.860391+00	20260818081211_add_activity_log_and_resume	\N	\N	2026-08-18 08:12:11.815167+00	1
bd535559-827e-46cf-998f-986a59591415	299b09fc96027f57aa6f7eb4a26bd79d35fda10ef5159b243be522cb46ae2dae	2026-08-18 13:07:53.557567+00	20260818130753_add_project_short_description	\N	\N	2026-08-18 13:07:53.543536+00	1
24b1ba59-dfff-4fb9-9caf-1ee7040859a7	189301af185a277a36e9282a58c5128dda7bc430f06a2545bdd0f4088c83520b	2026-08-18 13:46:39.383724+00	20260818134639_project_description_markdown	\N	\N	2026-08-18 13:46:39.338355+00	1
1c3a3b0b-3177-43f4-ba24-e11e44c41fec	d46a8e05ba674cb638dd10e3a3f854368bd824cd8e834f337e857f9c61804e1b	2026-08-19 08:31:32.056837+00	20260819083132_add_profile_identity_fields	\N	\N	2026-08-19 08:31:32.053197+00	1
b7d3d4a6-a7a3-461a-9e46-18f9a0eb1a79	ff7b47e7b5733f50c2a6cf65115d31e899eb7dba1f2d70784d248fa56ddf6748	2026-08-27 13:33:10.511177+00	20260827000000_replace_skills_feature_flag	\N	\N	2026-08-27 13:33:10.486353+00	1
602a5ac2-e8c5-4c28-9937-d87f51c64269	b4e30d10986605c4223957108da8045fba8997db7c4340a65d6a354c598fcd10	2026-08-27 13:33:10.517531+00	20260827115146_add_is_read_to_contact_message	\N	\N	2026-08-27 13:33:10.512274+00	1
c960c418-30d7-44da-bc36-0decdbf839f7	5001e2832edc0449bfda03bab9768e86f2b469c66ee93e2ce4495584ee278342	2026-08-31 09:13:54.944118+00	20260831081744_multi_language_descriptions	\N	\N	2026-08-31 09:13:54.925686+00	1
\.


--
-- Name: ActivityLog ActivityLog_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."ActivityLog"
    ADD CONSTRAINT "ActivityLog_pkey" PRIMARY KEY (id);


--
-- Name: ContactMessage ContactMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."ContactMessage"
    ADD CONSTRAINT "ContactMessage_pkey" PRIMARY KEY (id);


--
-- Name: FeatureFlag FeatureFlag_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."FeatureFlag"
    ADD CONSTRAINT "FeatureFlag_pkey" PRIMARY KEY (key);


--
-- Name: Organization Organization_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Organization"
    ADD CONSTRAINT "Organization_pkey" PRIMARY KEY (id);


--
-- Name: Profile Profile_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Profile"
    ADD CONSTRAINT "Profile_pkey" PRIMARY KEY (id);


--
-- Name: Project Project_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_pkey" PRIMARY KEY (id);


--
-- Name: ResumeDownload ResumeDownload_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."ResumeDownload"
    ADD CONSTRAINT "ResumeDownload_pkey" PRIMARY KEY (id);


--
-- Name: Resume Resume_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Resume"
    ADD CONSTRAINT "Resume_pkey" PRIMARY KEY (id);


--
-- Name: Role Role_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Role"
    ADD CONSTRAINT "Role_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: Skill Skill_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Skill"
    ADD CONSTRAINT "Skill_pkey" PRIMARY KEY (id);


--
-- Name: _ProjectToSkill _ProjectToSkill_AB_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."_ProjectToSkill"
    ADD CONSTRAINT "_ProjectToSkill_AB_pkey" PRIMARY KEY ("A", "B");


--
-- Name: _RoleToSkill _RoleToSkill_AB_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."_RoleToSkill"
    ADD CONSTRAINT "_RoleToSkill_AB_pkey" PRIMARY KEY ("A", "B");


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: ActivityLog_createdAt_idx; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "ActivityLog_createdAt_idx" ON public."ActivityLog" USING btree ("createdAt");


--
-- Name: Organization_name_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "Organization_name_key" ON public."Organization" USING btree (name);


--
-- Name: Project_slug_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "Project_slug_key" ON public."Project" USING btree (slug);


--
-- Name: ResumeDownload_createdAt_idx; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "ResumeDownload_createdAt_idx" ON public."ResumeDownload" USING btree ("createdAt");


--
-- Name: Session_tokenHash_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "Session_tokenHash_key" ON public."Session" USING btree ("tokenHash");


--
-- Name: Skill_name_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "Skill_name_key" ON public."Skill" USING btree (name);


--
-- Name: _ProjectToSkill_B_index; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "_ProjectToSkill_B_index" ON public."_ProjectToSkill" USING btree ("B");


--
-- Name: _RoleToSkill_B_index; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "_RoleToSkill_B_index" ON public."_RoleToSkill" USING btree ("B");


--
-- Name: ResumeDownload ResumeDownload_resumeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."ResumeDownload"
    ADD CONSTRAINT "ResumeDownload_resumeId_fkey" FOREIGN KEY ("resumeId") REFERENCES public."Resume"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Role Role_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Role"
    ADD CONSTRAINT "Role_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: _ProjectToSkill _ProjectToSkill_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."_ProjectToSkill"
    ADD CONSTRAINT "_ProjectToSkill_A_fkey" FOREIGN KEY ("A") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _ProjectToSkill _ProjectToSkill_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."_ProjectToSkill"
    ADD CONSTRAINT "_ProjectToSkill_B_fkey" FOREIGN KEY ("B") REFERENCES public."Skill"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _RoleToSkill _RoleToSkill_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."_RoleToSkill"
    ADD CONSTRAINT "_RoleToSkill_A_fkey" FOREIGN KEY ("A") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _RoleToSkill _RoleToSkill_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."_RoleToSkill"
    ADD CONSTRAINT "_RoleToSkill_B_fkey" FOREIGN KEY ("B") REFERENCES public."Skill"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 70YgxeobeC51HbNKB0W5X1WVtFNijL2PxcnxeJt6R2psgUSPpOXMKWKcRcbohVW

